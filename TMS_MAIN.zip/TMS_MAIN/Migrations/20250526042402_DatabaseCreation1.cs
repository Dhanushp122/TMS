﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TMS_MAIN.Migrations
{
    /// <inheritdoc />
    public partial class DatabaseCreation1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
