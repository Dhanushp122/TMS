﻿using Microsoft.AspNetCore.Mvc;

namespace TMS_MAIN.Controllers
{
    public class AdminController : Controller
    {
        public IActionResult AdminDashboard()
        {
            return View();
        }
    }
}
