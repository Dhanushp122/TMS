using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TMS_MAIN.Views.RiskManagement
{
    public class AnalyzeRiskModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
