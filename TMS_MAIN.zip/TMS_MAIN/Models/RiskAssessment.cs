﻿namespace TMS_MAIN.Models
{
    public class RiskAssessment
    {
    }
}
