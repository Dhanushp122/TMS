﻿public class TransactionRecordBase
{
}