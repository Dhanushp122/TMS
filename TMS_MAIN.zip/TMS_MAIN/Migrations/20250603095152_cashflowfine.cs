﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TMS_MAIN.Migrations
{
    /// <inheritdoc />
    public partial class cashflowfine : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "UserId",
                keyValue: 2,
                columns: new[] { "Address", "PhoneNumber" },
                values: new object[] { "bnc", "123456789" });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "UserId",
                keyValue: 2,
                columns: new[] { "Address", "PhoneNumber" },
                values: new object[] { "123 Main St", "1234567890" });
        }
    }
}
