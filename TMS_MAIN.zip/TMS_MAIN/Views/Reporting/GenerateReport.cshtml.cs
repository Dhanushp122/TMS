using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TMS_MAIN.Views.Reporting
{
    public class GenerateReportModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
