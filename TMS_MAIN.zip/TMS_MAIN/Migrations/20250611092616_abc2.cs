﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace TMS_MAIN.Migrations
{
    /// <inheritdoc />
    public partial class abc2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BankAccounts_Users_UserId",
                table: "BankAccounts");

            migrationBuilder.DropForeignKey(
                name: "FK_CashFlows_Users_UserId",
                table: "CashFlows");

            migrationBuilder.AlterColumn<string>(
                name: "BankName",
                table: "BankAccounts",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldMaxLength: 100);

            migrationBuilder.AlterColumn<decimal>(
                name: "Balance",
                table: "BankAccounts",
                type: "decimal(18,2)",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "decimal(15,2)");

            migrationBuilder.AlterColumn<string>(
                name: "AccountNumber",
                table: "BankAccounts",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldMaxLength: 50);

            migrationBuilder.UpdateData(
                table: "BankAccounts",
                keyColumn: "AccountId",
                keyValue: 1,
                columns: new[] { "AccountType", "UserId" },
                values: new object[] { 1, 2 });

            migrationBuilder.UpdateData(
                table: "BankAccounts",
                keyColumn: "AccountId",
                keyValue: 2,
                columns: new[] { "AccountNumber", "AccountType", "Balance" },
                values: new object[] { "2345678901", 0, 15000.00m });

            migrationBuilder.InsertData(
                table: "BankAccounts",
                columns: new[] { "AccountId", "AccountNumber", "AccountType", "Balance", "BankName", "UserId" },
                values: new object[,]
                {
                    { 3, "3456789012", 1, 12000.00m, "Wells Fargo", 1 },
                    { 4, "4567890123", 0, 25000.00m, "Citibank", 1 }
                });

            migrationBuilder.UpdateData(
                table: "CashFlows",
                keyColumn: "TransactionId",
                keyValue: 3,
                column: "AccountId",
                value: 3);

            migrationBuilder.UpdateData(
                table: "CashFlows",
                keyColumn: "TransactionId",
                keyValue: 4,
                column: "AccountId",
                value: 4);

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "UserId",
                keyValue: 3,
                columns: new[] { "Address", "Email", "FullName", "Password", "PhoneNumber" },
                values: new object[] { "mysuru", "treasurer1@company.com", "Default Treasurer", "treasurer", "583456789" });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "UserId", "Address", "Email", "FullName", "IsAdmin", "Password", "PhoneNumber", "Username" },
                values: new object[] { 4, "Bengaluru", "treasurer1@company.com", "Default Treasurer", false, "treasurer", "583456789", "treasurer2" });

            migrationBuilder.AddForeignKey(
                name: "FK_BankAccounts_Users_UserId",
                table: "BankAccounts",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_CashFlows_Users_UserId",
                table: "CashFlows",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BankAccounts_Users_UserId",
                table: "BankAccounts");

            migrationBuilder.DropForeignKey(
                name: "FK_CashFlows_Users_UserId",
                table: "CashFlows");

            migrationBuilder.DeleteData(
                table: "BankAccounts",
                keyColumn: "AccountId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "BankAccounts",
                keyColumn: "AccountId",
                keyValue: 4);

            migrationBuilder.DeleteData(
                table: "Users",
                keyColumn: "UserId",
                keyValue: 4);

            migrationBuilder.AlterColumn<string>(
                name: "BankName",
                table: "BankAccounts",
                type: "nvarchar(100)",
                maxLength: 100,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<decimal>(
                name: "Balance",
                table: "BankAccounts",
                type: "decimal(15,2)",
                nullable: false,
                oldClrType: typeof(decimal),
                oldType: "decimal(18,2)");

            migrationBuilder.AlterColumn<string>(
                name: "AccountNumber",
                table: "BankAccounts",
                type: "nvarchar(50)",
                maxLength: 50,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.UpdateData(
                table: "BankAccounts",
                keyColumn: "AccountId",
                keyValue: 1,
                columns: new[] { "AccountType", "UserId" },
                values: new object[] { 0, 1 });

            migrationBuilder.UpdateData(
                table: "BankAccounts",
                keyColumn: "AccountId",
                keyValue: 2,
                columns: new[] { "AccountNumber", "AccountType", "Balance" },
                values: new object[] { "0987654321", 1, 75000.00m });

            migrationBuilder.UpdateData(
                table: "CashFlows",
                keyColumn: "TransactionId",
                keyValue: 3,
                column: "AccountId",
                value: 1);

            migrationBuilder.UpdateData(
                table: "CashFlows",
                keyColumn: "TransactionId",
                keyValue: 4,
                column: "AccountId",
                value: 2);

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "UserId",
                keyValue: 3,
                columns: new[] { "Address", "Email", "FullName", "Password", "PhoneNumber" },
                values: new object[] { "bnc", "treasurer@company.com", "Dileep", "treasurer1", "123456789" });

            migrationBuilder.AddForeignKey(
                name: "FK_BankAccounts_Users_UserId",
                table: "BankAccounts",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_CashFlows_Users_UserId",
                table: "CashFlows",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
