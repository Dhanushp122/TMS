﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TMS_MAIN.Models
{
    public class BankAccount
    {
        [Key]
        [Required]
        public int AccountId { get; set; }
        
        public string BankName { get; set; }
        public string AccountNumber { get; set; }
        public AccountType AccountType { get; set; }
        public decimal Balance { get; set; }
        public int UserId { get; set; }
        public virtual User User { get; set; }

        // Add this property to fix the CS1061 error
        public virtual ICollection<CashFlow> CashFlows { get; set; }
    }

    public enum AccountType
    {
        Checking,
        Savings
    }
}