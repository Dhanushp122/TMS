using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TMS_MAIN.Views.BankAccount
{
    public class ReconcileAccountModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
