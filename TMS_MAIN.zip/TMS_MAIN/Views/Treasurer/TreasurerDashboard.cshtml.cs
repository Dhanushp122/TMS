using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TMS_MAIN.Views.Treasurer
{
    public class TreasurerDashboardModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}