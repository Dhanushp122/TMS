using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TMS_MAIN.Views.Investment
{
    public class PortfolioSummaryModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
