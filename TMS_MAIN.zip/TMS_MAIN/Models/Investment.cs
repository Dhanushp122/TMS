﻿
using System;

namespace TMS_MAIN.Models
{
    public class Investment
    {
        public int InvestmentId { get; set; }

        public InvestmentType InvestmentType { get; set; }
        public decimal AmountInvested { get; set; }
        public decimal CurrentValue { get; set; }
        public DateTime PurchaseDate { get; set; }
        public DateTime MaturityDate { get; set; }
        public int UserId { get; set; }
        public User User { get; set; }
    }
    public enum InvestmentType
    {
        Bonds,  // 0
        Equities, // 1
        MutualFunds // 2
    }

}
