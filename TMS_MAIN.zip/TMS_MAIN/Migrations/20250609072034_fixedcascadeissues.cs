﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace TMS_MAIN.Migrations
{
    /// <inheritdoc />
    public partial class fixedcascadeissues : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CashFlows_Users_UserId",
                table: "CashFlows");

            migrationBuilder.AddColumn<int>(
                name: "AccountId",
                table: "CashFlows",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "BankAccounts",
                columns: table => new
                {
                    AccountId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    BankName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    AccountNumber = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    AccountType = table.Column<int>(type: "int", nullable: false),
                    Balance = table.Column<decimal>(type: "decimal(15,2)", nullable: false),
                    UserId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BankAccounts", x => x.AccountId);
                    table.ForeignKey(
                        name: "FK_BankAccounts_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "BankAccounts",
                columns: new[] { "AccountId", "AccountNumber", "AccountType", "Balance", "BankName", "UserId" },
                values: new object[,]
                {
                    { 1, "1234567890", 0, 50000.00m, "Chase Bank", 1 },
                    { 2, "0987654321", 1, 75000.00m, "Bank of America", 2 }
                });

            migrationBuilder.UpdateData(
                table: "CashFlows",
                keyColumn: "TransactionId",
                keyValue: 1,
                column: "AccountId",
                value: 1);

            migrationBuilder.InsertData(
                table: "CashFlows",
                columns: new[] { "TransactionId", "AccountId", "Amount", "Description", "TransactionDate", "TransactionType", "UserId" },
                values: new object[,]
                {
                    { 2, 2, 15000.00m, "Office Supplies", new DateTime(2025, 2, 15, 0, 0, 0, 0, DateTimeKind.Unspecified), 1, 2 },
                    { 3, 1, 12000.00m, "Project Payment - Alpha", new DateTime(2025, 3, 1, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, 1 },
                    { 4, 2, 25000.00m, "Consulting Fee", new DateTime(2025, 3, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, 1 }
                });

            migrationBuilder.CreateIndex(
                name: "IX_CashFlows_AccountId",
                table: "CashFlows",
                column: "AccountId");

            migrationBuilder.CreateIndex(
                name: "IX_BankAccounts_UserId",
                table: "BankAccounts",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_CashFlows_BankAccounts_AccountId",
                table: "CashFlows",
                column: "AccountId",
                principalTable: "BankAccounts",
                principalColumn: "AccountId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_CashFlows_Users_UserId",
                table: "CashFlows",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CashFlows_BankAccounts_AccountId",
                table: "CashFlows");

            migrationBuilder.DropForeignKey(
                name: "FK_CashFlows_Users_UserId",
                table: "CashFlows");

            migrationBuilder.DropTable(
                name: "BankAccounts");

            migrationBuilder.DropIndex(
                name: "IX_CashFlows_AccountId",
                table: "CashFlows");

            migrationBuilder.DeleteData(
                table: "CashFlows",
                keyColumn: "TransactionId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "CashFlows",
                keyColumn: "TransactionId",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "CashFlows",
                keyColumn: "TransactionId",
                keyValue: 4);

            migrationBuilder.DropColumn(
                name: "AccountId",
                table: "CashFlows");

            migrationBuilder.AddForeignKey(
                name: "FK_CashFlows_Users_UserId",
                table: "CashFlows",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
