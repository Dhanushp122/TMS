﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TMS_MAIN.Migrations
{
    /// <inheritdoc />
    public partial class creatingrelationwithuser : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "UserId",
                table: "CashFlows",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_CashFlows_UserId",
                table: "CashFlows",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_CashFlows_Users_UserId",
                table: "CashFlows",
                column: "UserId",
                principalTable: "Users",
                principalColumn: "UserId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CashFlows_Users_UserId",
                table: "CashFlows");

            migrationBuilder.DropIndex(
                name: "IX_CashFlows_UserId",
                table: "CashFlows");

            migrationBuilder.DropColumn(
                name: "UserId",
                table: "CashFlows");
        }
    }
}
