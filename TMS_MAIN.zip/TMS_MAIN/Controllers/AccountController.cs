﻿using Microsoft.AspNetCore.Mvc;
using TMS_MAIN.Data;
using System.Linq;
using TMS_MAIN.Models;

namespace TMS_MAIN.Controllers
{
    public class AccountController : Controller
    {
        private readonly TreasuryManagementSystemContext _context;

        public AccountController(TreasuryManagementSystemContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string role, string username, string password)
        {
            var user = _context.Users.FirstOrDefault(u => u.Username == username && u.Password == password);

            if (user == null)
            {
                ViewBag.Message = "Invalid credentials.";
                return View();
            }

            // Fix: Ensure HttpContext.Session is used correctly
            HttpContext.Session.SetInt32("UserId", user.UserId);
            HttpContext.Session.SetString("FullName", user.FullName);
            HttpContext.Session.SetString("Username", user.Username);
            if (role == "admin" && user.IsAdmin)
            {
                return RedirectToAction("AdminDashboard", "Admin");
            }
            else if (role == "treasurer" && !user.IsAdmin)
            {
               
                return RedirectToAction("TreasurerDashboard", "Treasurer");
            }
            else
            {
                ViewBag.Message = "Role and credentials do not match.";
                return View();
            }
        }
    }
}