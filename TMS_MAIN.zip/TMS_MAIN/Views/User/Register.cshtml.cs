using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TMS_MAIN.Views.User
{
    public class RegisterModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
