﻿// Data/TreasuryManagementSystemContext.cs
using Microsoft.EntityFrameworkCore;
using TMS_MAIN.Models;
using System;

namespace TMS_MAIN.Data
{
    public class TreasuryManagementSystemContext : DbContext
    {
        public TreasuryManagementSystemContext(DbContextOptions<TreasuryManagementSystemContext> options)
            : base(options) { }

        // All DbSets from both contexts
        public DbSet<User> Users { get; set; }
        public DbSet<CashFlow> CashFlows { get; set; }
        public DbSet<Risk> RiskAssessments { get; set; } // Renamed from Risks and added from first context
        public DbSet<BankAccount> BankAccounts { get; set; }
        public DbSet<Investment> Investments { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // Using the connection string from the second context file.
                // You can modify this to match your actual database server and name.
                optionsBuilder.UseSqlServer("Server=LTIN563416\\SQLEXPRESS;Database=TMSMain;Integrated Security=True;TrustServerCertificate=True;Encrypt=False;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // User entity configuration
            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.UserId);
                entity.Property(e => e.Username).IsRequired().HasMaxLength(50);
                entity.Property(e => e.Password).IsRequired().HasMaxLength(100);
                entity.Property(e => e.IsAdmin).IsRequired();
                entity.Property(e => e.FullName).HasMaxLength(100);
                entity.Property(e => e.Email).HasMaxLength(100);
                entity.Property(e => e.PhoneNumber).HasMaxLength(15);
                entity.Property(e => e.Address).HasMaxLength(200);
            });

            // CashFlow relationships
            modelBuilder.Entity<CashFlow>()
                .HasOne(cf => cf.User)
                .WithMany(u => u.CashFlows)
                .HasForeignKey(cf => cf.UserId);

            modelBuilder.Entity<CashFlow>()
                .HasOne(c => c.BankAccount)
                .WithMany(b => b.CashFlows)
                .HasForeignKey(c => c.AccountId)
                .OnDelete(DeleteBehavior.Restrict);

            // BankAccount relationships
            modelBuilder.Entity<BankAccount>()
               .HasOne(b => b.User)
               .WithMany(u => u.BankAccounts)
               .HasForeignKey(b => b.UserId);

            // Investment relationship
            modelBuilder.Entity<Investment>()
                .HasOne(i => i.User)
                .WithMany(u => u.Investments)
                .HasForeignKey(i => i.UserId);

            // Risk entity configuration (from first context)
            modelBuilder.Entity<Risk>()
                .Property(r => r.Amount)
                .HasColumnType("decimal(18,2)");
            // Note: RiskScore and RiskLevel are typically calculated in the service, not directly seeded here.

            // Seed data for Users (from the second context as requested)
            modelBuilder.Entity<User>().HasData(
                new User
                {
                    UserId = 1,
                    Username = "admin",
                    Password = "admin", // Consider hashing passwords in a real application
                    IsAdmin = true,
                    FullName = "System Administrator",
                    Email = "admin@company.com",
                    PhoneNumber = "",
                    Address = ""
                },
                new User
                {
                    UserId = 2,
                    Username = "treasurer",
                    Password = "treasurer", // Consider hashing passwords in a real application
                    IsAdmin = false,
                    FullName = "Default Treasurer",
                    Email = "treasurer@company.com",
                    PhoneNumber = "123456789",
                    Address = "bnc"
                },
                new User
                {
                    UserId = 3,
                    Username = "treasurer1",
                    Password = "treasurer", // Corrected password to "treasurer" for consistency
                    IsAdmin = false,
                    FullName = "Default Treasurer",
                    Email = "treasurer1@company.com",
                    PhoneNumber = "583456789",
                    Address = "mysuru"
                },
                new User
                {
                    UserId = 4,
                    Username = "treasurer2",
                    Password = "treasurer",
                    IsAdmin = false,
                    FullName = "Default Treasurer",
                    Email = "treasurer1@company.com",
                    PhoneNumber = "583456789",
                    Address = "Bengaluru"
                }
            );

            // Seed data for BankAccounts
            modelBuilder.Entity<BankAccount>().HasData(
                new BankAccount
                {
                    AccountId = 1,
                    BankName = "Chase Bank",
                    AccountNumber = "1234567890",
                    AccountType = AccountType.Savings,
                    Balance = 50000.00m,
                    UserId = 2
                },
                new BankAccount
                {
                    AccountId = 2,
                    BankName = "Bank of America",
                    AccountNumber = "2345678901",
                    AccountType = AccountType.Checking,
                    Balance = 15000.00m,
                    UserId = 2
                },
                new BankAccount
                {
                    AccountId = 3,
                    BankName = "Wells Fargo",
                    AccountNumber = "3456789012",
                    AccountType = AccountType.Savings,
                    Balance = 12000.00m,
                    UserId = 1
                },
                new BankAccount
                {
                    AccountId = 4,
                    BankName = "Citibank",
                    AccountNumber = "4567890123",
                    AccountType = AccountType.Checking,
                    Balance = 25000.00m,
                    UserId = 1
                }
            );

            // Seed data for CashFlows
            modelBuilder.Entity<CashFlow>().HasData(
                new CashFlow
                {
                    TransactionId = 1,
                    Amount = 50000.00m,
                    TransactionType = TransactionType.Inflow,
                    TransactionDate = new DateTime(2025, 2, 10),
                    Description = "service tax",
                    UserId = 2,
                    AccountId = 1
                },
                new CashFlow
                {
                    TransactionId = 2,
                    Amount = 15000.00m,
                    TransactionType = TransactionType.Outflow,
                    TransactionDate = new DateTime(2025, 2, 15),
                    Description = "Office Supplies",
                    UserId = 2,
                    AccountId = 2
                },
                new CashFlow
                {
                    TransactionId = 3,
                    Amount = 12000.00m,
                    TransactionType = TransactionType.Inflow,
                    TransactionDate = new DateTime(2025, 3, 1),
                    Description = "Project Payment - Alpha",
                    UserId = 1,
                    AccountId = 3
                },
                new CashFlow
                {
                    TransactionId = 4,
                    Amount = 25000.00m,
                    TransactionType = TransactionType.Inflow,
                    TransactionDate = new DateTime(2025, 3, 10),
                    Description = "Consulting Fee",
                    UserId = 1,
                    AccountId = 4
                }
            );

            // Seed data for Investments
            modelBuilder.Entity<Investment>().HasData(
                new Investment
                {
                    InvestmentId = 1,
                    InvestmentType = InvestmentType.Bonds,
                    AmountInvested = 10000,
                    CurrentValue = 10500,
                    PurchaseDate = new DateTime(2024, 1, 15),
                    MaturityDate = new DateTime(2026, 1, 15),
                    UserId = 2
                },
                new Investment
                {
                    InvestmentId = 2,
                    InvestmentType = InvestmentType.MutualFunds,
                    AmountInvested = 20000,
                    CurrentValue = 25000,
                    PurchaseDate = new DateTime(2023, 6, 10),
                    MaturityDate = new DateTime(2025, 6, 10),
                    UserId = 3
                }
            );
        }
    }
}