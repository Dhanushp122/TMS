﻿using Microsoft.AspNetCore.Mvc;
using TMS_MAIN.Data;
using TMS_MAIN.Models;

namespace TMS_MAIN.Controllers
{
    public class UserController : Controller
    {
        private readonly TreasuryManagementSystemContext _context;

        public UserController(TreasuryManagementSystemContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(User user)
        {
            if (ModelState.IsValid)
            {
                _context.Users.Add(user);
                _context.SaveChanges();
                return RedirectToAction("UserList");
            }
            return View(user);
        }

        public IActionResult UserList()
        {
            var users = _context.Users.ToList();
            return View(users);
        }
    }
}