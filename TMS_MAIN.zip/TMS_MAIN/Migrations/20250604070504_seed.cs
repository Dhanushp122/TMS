﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TMS_MAIN.Migrations
{
    /// <inheritdoc />
    public partial class seed : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "CashFlows",
                columns: new[] { "TransactionId", "Amount", "Description", "TransactionDate", "TransactionType", "UserId" },
                values: new object[] { 1, 50000.00m, "service tax", new DateTime(2025, 2, 10, 0, 0, 0, 0, DateTimeKind.Unspecified), 0, 2 });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "CashFlows",
                keyColumn: "TransactionId",
                keyValue: 1);
        }
    }
}
