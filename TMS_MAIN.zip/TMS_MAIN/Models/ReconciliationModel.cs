﻿public class ReconciliationModel
{
    public int BankAccountId { get; set; }
    public string BankName { get; set; }
    public string AccountNumber { get; set; }

  //  public IFormFile BankStatementFile { get; set; }
   // public IFormFile InternalTransactionFile { get; set; }
}


    